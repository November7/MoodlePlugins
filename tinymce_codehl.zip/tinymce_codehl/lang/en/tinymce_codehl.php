<?php

$string['pluginname'] 				    = 'Code Highlighter';
$string['codehl:desc'] 			    	= 'Code Highlighter';
$string['codehl:titleLabel']	    	= 'Insert Code';
$string['codehl:languageLabel']     	= 'Choose the language';
$string['codehl:parserJS']              = 'JavaScript';
$string['codehl:parserPHP']             = 'PHP';
$string['codehl:usejavascriptparser']   = 'Choose parser<br />JavaScript parser need plugin filter: codehiglighter';
$string['codehl:headerLabel'] 	    	= 'Header';
$string['codehl:numLabel'] 		    	= 'Show line numbers';
$string['codehl:numOnLabel']	    	= 'Yes';
$string['codehl:numOffLabel'] 	    	= 'No';
$string['codehl:startNumberLabel']  	= 'Start number';
$string['codehl:widthLabel']	    	= 'Width';
$string['codehl:textareaLabel']     	= 'Sourcecode';
$string['codehl:pcLabel'] 		    	= 'Percent';
$string['codehl:pxLabel'] 		    	= 'Pixels'; 

$string['codehl:cancelLabel']	    	= 'Cancel';
$string['codehl:insertLabel'] 	    	= 'Insert';
$string['codehl:themeLabel'] 		    = 'Select theme';
$string['codehl:normaltheme'] 	    	= 'Standard';
$string['codehl:darktheme'] 	    	= 'Dark';

?>