<?php

$string['pluginname'] 				    = 'Code Highlighter';
$string['codehl:desc'] 			    	= 'Code Highlighter';
$string['codehl:titleLabel']	    	= 'Wstaw kod źrółowy';
$string['codehl:languageLabel']     	= 'Wybierz język programowania';
$string['codehl:parserJS']              = 'JavaScript';
$string['codehl:parserPHP']             = 'PHP';
$string['codehl:usejavascriptparser']   = 'Wybierz parser<br />JavaScript wymaga dodatku - filtr: codehiglighter';
$string['codehl:headerLabel'] 	    	= 'Nagówek';
$string['codehl:numLabel'] 		    	= 'Pokaż numery linii';
$string['codehl:numOnLabel']	    	= 'Tak';
$string['codehl:numOffLabel'] 	    	= 'Nie';
$string['codehl:startNumberLabel']	    = 'Rozpocznij numerowanie od';
$string['codehl:widthLabel']	    	= 'Szerokość';
$string['codehl:textareaLabel']     	= 'Kod źrółowy';
$string['codehl:pcLabel'] 		    	= 'Procent';
$string['codehl:pxLabel'] 		    	= 'Pixeli';
$string['codehl:cancelLabel']	    	= 'Anuluj';
$string['codehl:insertLabel'] 	    	= 'Wstaw';  

$string['codehl:themeLabel'] 	    	= 'Wybierz wygląd';
$string['codehl:normaltheme'] 	    	= 'Standardowy';
$string['codehl:darktheme'] 	    	= 'Ciemny';



?>