# codeHL
TinyMCE plugin for Moodle 3.0+