<?php

defined('MOODLE_INTERNAL') || die();
$plugin->version   = 2022091801;        // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires  = 2016051900;        // Requires this Moodle version
$plugin->component = 'filter_codehighlighter'; // Full name of the plugin (used for diagnostics)

?>