<?php

$string['filtername'] = 'CodeHighlighter Filter';
$string['pluginname'] = 'CodeHighlighter Filter';

?>